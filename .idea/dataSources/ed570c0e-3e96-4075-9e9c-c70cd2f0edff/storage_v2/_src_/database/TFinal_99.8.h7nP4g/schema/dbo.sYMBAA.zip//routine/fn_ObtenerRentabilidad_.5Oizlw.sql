create function fn_ObtenerRentabilidad_(@cprod int, @date1 date, @date2 date)
        returns table
            as
            return
                (
                    select                       vw.CProducto,
                                                 P.NProducto,
                        PrecioPromedioFiltrado = avg(DC.MParcial),
                                                 'PRECIO FILTRADO' as tipodeBusqueda
                    from vw_montoPorProducto_ vw
                             join Detalle_Compra DC on vw.CProducto = DC.CProducto
                             join Producto P on DC.CProducto = P.CProducto
                             join Compra_Proveedor CP on CP.CCompra = DC.CCompra
                    where vw.CProducto = @cprod
                      and CP.DCompra between @date1 and @date2
                    group by vw.CProducto, P.NProducto
                    UNION
                    select               vw1.CProducto,
                                         P1.NProducto,
                        PrecioPromedio = avg(DC1.MParcial),
                                         'PRECIO GENERAL' as tipodeBusqueda
                    from vw_montoPorProducto_ vw1
                             join Detalle_Compra DC1 on vw1.CProducto = DC1.CProducto
                             join Producto P1 on P1.CProducto = DC1.CProducto
                    where vw1.CProducto = @cprod
                    group by vw1.CProducto, P1.NProducto
                )
go

