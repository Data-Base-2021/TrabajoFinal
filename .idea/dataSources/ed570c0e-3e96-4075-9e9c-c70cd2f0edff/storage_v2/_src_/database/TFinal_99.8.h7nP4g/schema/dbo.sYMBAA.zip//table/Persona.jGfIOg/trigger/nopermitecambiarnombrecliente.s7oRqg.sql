create TRIGGER nopermitecambiarnombrecliente

        ON Persona

        FOR UPDATE
        AS
        IF UPDATE(NPersona)

/* que es loq que hara el trigger */
            BEGIN
                RAISERROR (15600,-1,-1,'No puede cambiar el nombre del cliente');

                ROLLBACK TRANSACTION

            END
go

