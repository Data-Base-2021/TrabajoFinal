CREATE PROCEDURE EMPLEADOLIKEAPELLIDO @APELLIDOPATERNO VARCHAR(30)
            AS

            SELECT p.CPersona,
                   p.NPersona,
                   p.NApellidoPaterno,
                   s.NSede
            FROM Sede s
                     join Empleado e on s.CSede = e.CSede
                     join Persona p on e.CEmpleado = p.CPersona

            WHERE p.NApellidoPaterno LIKE '%' + @APELLIDOPATERNO + '%'
go

