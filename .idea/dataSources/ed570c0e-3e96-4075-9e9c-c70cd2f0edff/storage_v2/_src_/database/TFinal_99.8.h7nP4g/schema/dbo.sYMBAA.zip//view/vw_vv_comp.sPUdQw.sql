Create VIEW vw_vv_comp as
select vv.CVentaVirtual, SUM(V.MTotal) 'Monto', v.DVenta, v.CVenta
from Venta v
         join VentaVirtual vv on v.CVenta = vv.CVentaVirtual
group by vv.CVentaVirtual, v.DVenta, v.CVenta
go

