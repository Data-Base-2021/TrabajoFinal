Create VIEW vw_vp_comp as
select vp.CVentaPresencial, SUM(V.MTotal) 'Monto', v.DVenta, v.CVenta
from Venta v
         join VentaPresencial vp on v.CVenta = vp.CVentaPresencial
group by vp.CVentaPresencial, v.DVenta, v.CVenta
go

