create procedure pr_ultimovalorcampaña_
            as
            declare
                micursor cursor scroll
                    for select año, mes, monto
                        from vw_mONTOtOTALcAMPAÑAS
                open micursor
                fetch last from micursor
                close micursor
                deallocate micursor
go

