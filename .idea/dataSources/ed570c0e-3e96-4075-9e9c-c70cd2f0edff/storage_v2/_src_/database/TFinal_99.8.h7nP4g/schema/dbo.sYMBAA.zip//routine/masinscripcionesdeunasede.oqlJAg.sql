CREATE FUNCTION masinscripcionesdeunasede(@csede INT, @fecha_inicio date, @fecha_final date)

                    RETURNS TABLE
                        AS
                        RETURN
                            (
                                select s.CSede, s.NSede, COUNT(i.CInscripcion) 'cantidad de inscripcion'
                                from Inscripcion i
                                         join PlanSede ps on i.CPlan = ps.CPlan
                                         join Sede s on s.CSede = ps.CSede
                                where s.CSede = @csede
                                  and (i.DIncripcion between @fecha_inicio and @fecha_final)
                                group by s.CSede, s.NSede
                            )
go

