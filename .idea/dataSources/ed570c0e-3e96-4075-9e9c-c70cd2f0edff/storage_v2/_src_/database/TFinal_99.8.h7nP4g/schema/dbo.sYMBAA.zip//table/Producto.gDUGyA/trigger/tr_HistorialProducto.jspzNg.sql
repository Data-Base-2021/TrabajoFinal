create trigger tr_HistorialProducto
                            on Producto
                            after update
                            as
                            set nocount on
                        begin
                            --if update(NProducto or MPrecio or CProducto )
                            --begin
                            declare @prevPrice money
                            declare @newPrice money
                            declare @code int
                            declare @prevName varchar(30)
                            declare @newName varchar(30)

                            select @prevPrice = d.MPrecio,
                                   @newPrice = i.MPrecio,
                                   @Code = i.CProducto,
                                   @prevName = d.NProducto,
                                   @newName = i.NProducto
                            from deleted d
                                     inner join inserted i on d.CProducto = i.CProducto
                            insert into HistorialProductos
                            values (getdate(), system_user, @Code, @prevName, @newName, @prevPrice, @newPrice)
                            --end
                        end
go

