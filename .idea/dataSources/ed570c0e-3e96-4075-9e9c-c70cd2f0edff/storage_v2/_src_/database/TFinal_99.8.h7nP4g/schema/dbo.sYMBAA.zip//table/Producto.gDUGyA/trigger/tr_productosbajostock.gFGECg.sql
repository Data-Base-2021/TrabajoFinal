create trigger tr_productosbajostock
--DONDE SE DISPARA EL EVENTO (TABLA)
            on Producto --tabla donde se dispara el evento
            for Update --CUANDO SE DISPARA EL EVENTO
            as
        begin
            --QUE DEBE HACER

            if UPDATE(stock)
                begin
                    insert into tb_productobajoenstock
                    select GETDATE(), 'Limite de stock del producto: ' + rtrim(ltrim(str(CProducto))), stock
                    from inserted
                    where stock <= 10
                end
        end
go

