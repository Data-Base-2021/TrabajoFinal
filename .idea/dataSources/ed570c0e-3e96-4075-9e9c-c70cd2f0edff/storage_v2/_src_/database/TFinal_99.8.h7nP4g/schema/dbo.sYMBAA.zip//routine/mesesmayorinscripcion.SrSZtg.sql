create procedure mesesmayorinscripcion as
    begin
        Declare @promedio NUMERIC(10, 2);

        select @promedio = AVG(total)
        from (
                 select DATEPART(MONTH, DIncripcion) mes, count(1) total
                 from Inscripcion
                 group by DATEPART(MONTH, DIncripcion)
             ) a;

        select @promedio promedio;
        WITH meses AS
                 (
                     SELECT ROW_NUMBER() OVER (ORDER BY value DESC) AS ID,
                            value
                     FROM STRING_SPLIT(
                             'ENERO,FEBRERO,MARZO,ABRIL,MAYO,JUNIO,JULIO,AGOSTO,SETIEMBRE,OCTUBRE,NOVIEMBRE,DICIEMBRE',
                             ',')
                 )
        Select m.value, prom.total
        from (select DATEPART(MONTH, DIncripcion) mes, count(1) total
              from Inscripcion
              group by DATEPART(MONTH, DIncripcion)
              having count(1) > @promedio
             ) prom
                 Join meses m On prom.mes = m.ID

    end
go

