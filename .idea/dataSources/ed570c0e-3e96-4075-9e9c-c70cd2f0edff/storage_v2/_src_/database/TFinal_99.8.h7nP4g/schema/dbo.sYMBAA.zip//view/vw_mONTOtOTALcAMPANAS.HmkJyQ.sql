create view vw_mONTOtOTALcAMPAÑAS AS
    select año = datepart(year, c.DInicio), mes = datepart(month, c.DInicio), monto = sum(c.MInvertido)
    from Campania c
    group by datepart(year, c.DInicio), datepart(month, c.DInicio)
go

