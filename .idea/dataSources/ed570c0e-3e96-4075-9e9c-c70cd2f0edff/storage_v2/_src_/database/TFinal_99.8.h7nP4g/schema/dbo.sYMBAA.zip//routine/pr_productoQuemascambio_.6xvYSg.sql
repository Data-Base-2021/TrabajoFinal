create procedure pr_productoQuemascambio_ @maxmin char
                            as
                                if @maxmin = 's'
                                    begin
                                        select vecesModificado = max(vecesModificado), v2.cproducto
                                        from vw_vecesqunproductocambia_ v2
                                        group by v2.cproducto
                                        having max(vecesModificado) = all (
                                            select max(v3.vecesModificado)
                                            from vw_vecesqunproductocambia_ v3
                                        )
                                    end
                                else
                                    begin
                                        select vecesModificado= min(v4.vecesModificado), v4.cproducto
                                        from vw_vecesqunproductocambia_ v4
                                        group by v4.cproducto
                                        having min(v4.vecesModificado) = all (
                                            select min(v5.vecesModificado)
                                            from vw_vecesqunproductocambia_ v5
                                        )
                                    end
go

