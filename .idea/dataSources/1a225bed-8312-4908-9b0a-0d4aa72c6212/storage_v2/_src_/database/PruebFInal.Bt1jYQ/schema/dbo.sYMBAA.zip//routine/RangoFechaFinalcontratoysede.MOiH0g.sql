CREATE PROCEDURE RangoFechaFinalcontratoysede
@RFECHAINICIAL date,
@RFECHAFINAL date ,
@SEDE NVARCHAR(30)
AS


SELECT p.CPersona,p.NPersona,s.NSede,e.DFinalContrato FROM
Sede s join Empleado e on s.CSede=e.CSede
join Persona p on e.CEmpleado=p.CPersona
join TurnoTrabajo t on e.CTurno=t.CTurno where  e.DFinalContrato between @RFECHAINICIAL and @RFECHAFINAL and s.NSede=@SEDE
go

