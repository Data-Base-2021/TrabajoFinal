CREATE view vw_promediomontoventa as

        select d.NDistrito, SUM(pv.MParcial * pv.QProducto) 'monto'
        from Distrito d
                 join VentaVirtual vv on d.CDistrito = vv.CDistrito
                 join Venta v on vv.CVentaVirtual = v.CVenta
                 join ProductoVenta pv on v.CVenta = pv.CVenta
        group by d.NDistrito
go

