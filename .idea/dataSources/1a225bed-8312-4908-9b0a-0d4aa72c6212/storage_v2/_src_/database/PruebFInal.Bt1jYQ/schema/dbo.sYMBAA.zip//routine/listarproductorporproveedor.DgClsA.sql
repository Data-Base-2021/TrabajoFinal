CREATE FUNCTION listarproductorporproveedor(@codigoproveedor int)
RETURNS TABLE
AS
RETURN
(
 select p.CProveedor,p.NProveedor,pr.CProducto,pr.NProducto from Proveedor p
join Compra_Proveedor cp on p.CProveedor=cp.CProveedor
join Detalle_Compra dc on dc.CCompra=cp.CCompra
join Producto pr on dc.CProducto=  pr.CProducto where p.CProveedor=@codigoproveedor
group by p.CProveedor,p.NProveedor,pr.CProducto,pr.NProducto
)
go

