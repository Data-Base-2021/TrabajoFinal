create view vw_vecesqunproductocambia_ as
    select hp.cproducto, count(hp.cproducto) as vecesModificado
    from HistorialProductos hp
    group by hp.cproducto
go

