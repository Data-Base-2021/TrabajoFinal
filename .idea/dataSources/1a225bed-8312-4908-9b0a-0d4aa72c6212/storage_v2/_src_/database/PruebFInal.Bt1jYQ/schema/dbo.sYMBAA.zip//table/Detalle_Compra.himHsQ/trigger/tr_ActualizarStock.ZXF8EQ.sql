create trigger tr_ActualizarStock
    on Detalle_Compra for insert
    as
    set nocount on
    update Producto set Producto.stock = Producto.stock  +  inserted.QProducto
    from inserted join Producto on Producto.CProducto = inserted.CProducto;
go

