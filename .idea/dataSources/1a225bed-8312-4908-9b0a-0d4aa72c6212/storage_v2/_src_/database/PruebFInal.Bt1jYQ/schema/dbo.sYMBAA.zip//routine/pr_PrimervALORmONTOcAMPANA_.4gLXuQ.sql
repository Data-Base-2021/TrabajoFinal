create procedure pr_PrimervALORmONTOcAMPAÑA_
    as
    declare
        mycursor cursor scroll
            for select año, mes, monto
                from vw_mONTOtOTALcAMPAÑAS
        open mycursor
        fetch first from mycursor
        close mycursor
        deallocate mycursor
go

