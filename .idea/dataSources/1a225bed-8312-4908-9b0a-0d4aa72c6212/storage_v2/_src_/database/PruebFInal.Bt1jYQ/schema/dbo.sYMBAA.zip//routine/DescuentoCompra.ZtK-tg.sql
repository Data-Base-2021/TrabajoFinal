create function DescuentoCompra(@fecha_inicio date ,@fecha_final date, @monto money)
returns table
as
return(
select u.CUsuario, p.NPersona, p.NApellidoPaterno, v.DVenta ,SUM(V.MTotal) 'Monto',pr.NProducto,SUM(pv.QProducto * pv.MParcial) 'MontoxProducto'
from Persona p join Usuario u on p.CPersona = u.CUsuario
			   join Venta v on v.CPersona = u.CUsuario
			   join ProductoVenta pv on pv.CVenta = v.CVenta
			   join Producto pr on pr.CProducto = pv.CProducto
where v.DVenta between @fecha_inicio and @fecha_final
group by u.CUsuario, p.NPersona, p.NApellidoPaterno, v.DVenta, pr.NProducto, pv.MParcial
having (SUM(V.MTotal) >= @monto) and  (SUM(pv.QProducto * pv.MParcial)) >= (SUM(v.MTotal)/2)
)
go

