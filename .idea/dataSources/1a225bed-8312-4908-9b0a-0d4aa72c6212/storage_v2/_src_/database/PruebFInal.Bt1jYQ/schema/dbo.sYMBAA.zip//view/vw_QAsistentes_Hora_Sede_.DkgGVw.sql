create view vw_QAsistentes_Hora_Sede_ as
select s.CSede, horario = datepart(hour, RH.DRegistro), QAsistentes= count(RH.CReservaHorario)
from Sede s
         join ReservaHorario RH on s.CSede = RH.CSede
group by s.CSede, datepart(hour, RH.DRegistro)
go

