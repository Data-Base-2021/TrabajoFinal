create Procedure pr_CalcularCantidadAsistentes @valor int,
                                               @maxmin int
as
    if @maxmin = 1
        begin
            select vQAHS.CSede, vQAHS.horario, vQAHS.QAsistentes
            from vw_QAsistentes_Hora_Sede_ vQAHS
            where vQAHS.QAsistentes > @valor
        end
    else
        begin
            select vQAHS.CSede, vQAHS.horario, vQAHS.QAsistentes
            from vw_QAsistentes_Hora_Sede_ vQAHS
            where vQAHS.QAsistentes < @valor
        end
go

