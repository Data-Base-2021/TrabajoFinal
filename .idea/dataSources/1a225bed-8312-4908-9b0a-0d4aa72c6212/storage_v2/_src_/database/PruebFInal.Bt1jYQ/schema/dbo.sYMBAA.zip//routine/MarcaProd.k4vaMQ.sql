CREATE function MarcaProd(@fecha_inicio date ,@fecha_final date)
returns table
as
return(
select m.CMarca, m.NMarca, mo.NModelo, SUM(pv.QProducto) 'Ventas'
from Marca m join Modelo mo on m.CMarca = mo.CMarca
			 join Producto p on p.CModelo = mo.CModelo
			 join ProductoVenta pv on pv.CProducto = p.CProducto
			 join Venta v on v.CVenta = pv.CVenta
where v.DVenta between @fecha_inicio and @fecha_final
group by m.CMarca, m.NMarca, mo.NModelo
having SUM(pv.QProducto) >=(Select MAX(nv.Ventas)
					  FROM( 
					  select m.CMarca, m.NMarca, mo.NModelo,  SUM(pv.QProducto) 'Ventas'
					  from Marca m join Modelo mo on m.CMarca = mo.CMarca
					  join Producto p on p.CModelo = mo.CModelo
					  join ProductoVenta pv on pv.CProducto = p.CProducto
					  join Venta v on v.CVenta = pv.CVenta
					  where v.DVenta between @fecha_inicio and @fecha_final
				  	  group by m.CMarca, m.NMarca, mo.NModelo)AS nv)
)
go

