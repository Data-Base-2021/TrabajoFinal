create view vw_repar_venta as
select r.CRepartidor, p.NPersona, Sum(pv.QProducto) 'Venta'
from Persona p join Repartidor r  on p.CPersona = r.CRepartidor
			   join VentaVirtual vv on  vv.CRepartridor = r.CRepartidor
			   join Venta v on v.CVenta = vv.CVentaVirtual
			   join ProductoVenta pv on pv.CVenta = v.CVenta
group by r.CRepartidor, p.NPersona
go

