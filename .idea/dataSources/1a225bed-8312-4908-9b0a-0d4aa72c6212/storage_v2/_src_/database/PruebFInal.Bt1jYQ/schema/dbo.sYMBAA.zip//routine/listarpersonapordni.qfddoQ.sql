CREATE FUNCTION listarpersonapordni (@cpersona  int)
RETURNS @persona TABLE
(
CPersona int, NPersona nvarchar(50),TAvenida text
)
AS
BEGIN
INSERT @persona SELECT CPersona,NPersona,TAvenida FROM Persona
WHERE CPersona=@cpersona
RETURN
END
go

