create function Invitados(@cantidad int)
returns table
as
return(
select s.CSede, s.NSede, d.NDistrito, COUNT(ri.CInvitado) 'Q_Invitado'
from Sede s join Distrito d on s.Distrito_CDistrito = d.CDistrito
			join Inscripcion i on i.CSede = s.CSede
			join Usuario u on i.CUsuario = u.CUsuario
			join ReservaHorario rh on rh.CUsuario = u.CUsuario
			join RegistroInvitado ri on ri.CReservaHorario = rh.CReservaHorario
group by  s.CSede, s.NSede, d.NDistrito
having COUNT(ri.CInvitado) > @cantidad
)
go

