CREATE view vw_montoPorProducto_ as
select DC.CProducto,montoTotalxproducto = sum(DC.MParcial)
from Compra_Proveedor cp join Detalle_Compra DC on cp.CCompra = DC.CCompra join Producto P on P.CProducto = DC.CProducto
group by DC.CProducto
go

