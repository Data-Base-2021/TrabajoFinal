create procedure pr_cualquiercosa_ as
begin
    select s.NSede, d.NDistrito, Count(i.CEmpleado) 'cantidad de usuarios', sum(pl.MPrecio) 'Monto'
    from Distrito d
             join Sede s on d.CDistrito = s.Distrito_CDistrito
             join PlanSede pl on s.CSede = pl.CSede
             join Inscripcion i on i.CPlan = pl.CPlan

    group by s.NSede, d.NDistrito
end
go

